EqDistant
=========

This is a QGIS plugin to create an equidistant line to determine maritime boundary based on equidistance principle.
