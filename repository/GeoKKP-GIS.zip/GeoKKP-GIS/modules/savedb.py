# import os
# import re

# from qgis.PyQt.QtCore import Qt, QTimer, QUrl
# from qgis.gui import QgsRubberBand

# from PyQt5 import uic
# from PyQt5.QtWidgets import QAction, QMessageBox
# from qgis.core import (Qgis,
#                     QgsCoordinateReferenceSystem,
#                     QgsCoordinateTransform,
#                     QgsRectangle,
#                     QgsPoint,
#                     QgsPointXY,
#                     QgsGeometry,
#                     QgsWkbTypes,
#                     QgsVectorLayer,
#                     QgsFeature,
#                     QgsProject, QgsApplication)
# from qgis.PyQt import QtGui, QtWidgets, uic
# from qgis.PyQt.QtCore import pyqtSignal
# from qgis.utils import iface
